#Intro to Node

*What is Node?
*Why are we learning it?
    *It's popular!
    * Javascript!!!! 
*(it doesn't matter(long term))


#using node
* Interact with node console -> just type in node in terminal 
* Run a file with node
node <filename>


